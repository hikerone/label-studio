// Find a genuinely empty rectangle inside one label. Coordinates are top-left pixels.
// Cells with any dark pixel are blocked, and a clearance ring protects nearby content.
export function findBlankPlacement(image,{aspect=3,maxWidthIn=3.3,minWidthIn=1.1,dpi=100,marginIn=.12,clearanceIn=.12}={}){
  const {data,width,height}=image,cell=Math.max(2,Math.round(dpi/32)),cols=Math.ceil(width/cell),rows=Math.ceil(height/cell);
  const blocked=new Uint8Array(cols*rows);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const i=(y*width+x)*4;
    if(data[i+3]>32&&(data[i]<245||data[i+1]<245||data[i+2]<245))blocked[Math.floor(y/cell)*cols+Math.floor(x/cell)]=1;
  }
  const radius=Math.ceil(clearanceIn*dpi/cell),expanded=new Uint8Array(blocked.length);
  let firstInk=rows,lastInk=-1,bottomDivider=-1;
  const minimumHeight=Math.max(1,Math.ceil(Math.ceil(minWidthIn*dpi/cell)/aspect));
  for(let y=0;y<rows;y++){
    let occupied=0;
    for(let x=0;x<cols;x++)if(blocked[y*cols+x]){firstInk=Math.min(firstInk,y);lastInk=Math.max(lastInk,y);occupied++;}
    // A near-continuous rule in the lower part of a label can separate a
    // footer from the address and tracking sections. Ignore the page border.
    if(y>=rows*.75&&y<=rows-marginIn*dpi/cell-radius-minimumHeight&&occupied>=cols*.9)bottomDivider=y;
  }
  for(let y=0;y<rows;y++)for(let x=0;x<cols;x++)if(blocked[y*cols+x])for(let yy=Math.max(0,y-radius);yy<=Math.min(rows-1,y+radius);yy++)for(let xx=Math.max(0,x-radius);xx<=Math.min(cols-1,x+radius);xx++)expanded[yy*cols+xx]=1;
  const stride=cols+1,sum=new Uint32Array((rows+1)*stride);
  for(let y=0;y<rows;y++)for(let x=0;x<cols;x++)sum[(y+1)*stride+x+1]=expanded[y*cols+x]+sum[y*stride+x+1]+sum[(y+1)*stride+x]-sum[y*stride+x];
  const empty=(x,y,w,h)=>sum[(y+h)*stride+x+w]-sum[y*stride+x+w]-sum[(y+h)*stride+x]+sum[y*stride+x]===0;
  const margin=Math.ceil(marginIn*dpi/cell),maxW=Math.min(cols-2*margin,Math.floor(maxWidthIn*dpi/cell));
  for(let w=maxW;w>=Math.ceil(minWidthIn*dpi/cell);w--){
    const h=Math.max(1,Math.ceil(w/aspect));if(h>rows-2*margin)continue;
    // Prefer topmost blank areas, then horizontal center.
    for(let y=margin;y<=rows-margin-h;y++){
      // Interior gaps are off-limits. A footer is eligible only below a clear
      // full-width divider, with pixel-level clearance around any footer code.
      const topBand=y+h<=firstInk-radius;
      const bottomBand=bottomDivider>=0&&y>bottomDivider+radius;
      if(lastInk>=0&&!topBand&&!bottomBand)continue;
      let best=null;
      for(let x=margin;x<=cols-margin-w;x++)if(empty(x,y,w,h)&&(!best||Math.abs(x+(w-cols)/2)<Math.abs(best+(w-cols)/2)))best=x;
      if(best!==null)return {x:best*cell,y:y*cell,width:w*cell,height:h*cell};
    }
  }
  return null;
}

export async function placeSixOnEight(PDFLib,sourceBytes,artBytes=null){
  const source=await PDFLib.PDFDocument.load(sourceBytes),output=await PDFLib.PDFDocument.create(),art=artBytes?await output.embedPng(artBytes):null;
  for(const original of source.getPages()){
    if(Math.abs(original.getWidth()-288)>.01||Math.abs(original.getHeight()-432)>.01)throw new Error('The 4 × 6 source must be exactly 4 × 6 inches.');
    const page=output.addPage([288,576]),embedded=await output.embedPage(original);
    page.drawPage(embedded,{x:0,y:0,width:288,height:432});
    if(art){const w=Math.min(252,art.width/art.height*106),h=w*art.height/art.width;page.drawImage(art,{x:(288-w)/2,y:432+(144-h)/2,width:w,height:h});}
  }
  output.setTitle('4 × 6 shipping labels on 4 × 8 paper');output.setCreator('Label Studio');return output.save();
}
