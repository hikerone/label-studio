export const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
export function normalizeCrop(crop) {
  const x = clamp(Number(crop.x) || 0, 0, .99);
  const y = clamp(Number(crop.y) || 0, 0, .99);
  return { x, y, w: clamp(Number(crop.w) || .01, .01, 1 - x), h: clamp(Number(crop.h) || .01, .01, 1 - y) };
}
export function presetCrop(preset) {
  return ({full:{x:0,y:0,w:1,h:1},top:{x:0,y:0,w:1,h:.5},bottom:{x:0,y:.5,w:1,h:.5},left:{x:0,y:0,w:.5,h:1},right:{x:.5,y:0,w:.5,h:1}})[preset];
}
// Find separate printed blocks separated by white horizontal bands. No carrier-specific
// coordinates are guessed. A candidate needs a label-like aspect ratio and substantial ink.
export function detectCrop(image, pageWidth, pageHeight) {
  const {width, height, data} = image;
  if (Math.abs(pageWidth / pageHeight - 2/3) < .035 || Math.abs(pageWidth / pageHeight - 1.5) < .04) return {crop:presetCrop('full'),reason:'This page already has a 4×6 shape. The full page is selected.'};
  const rows = new Uint32Array(height);
  let all = {left:width,top:height,right:0,bottom:0,count:0};
  for(let y=0;y<height;y++) for(let x=0;x<width;x++) {
    const i=(y*width+x)*4;
    if(data[i+3]>100 && Math.min(data[i],data[i+1],data[i+2])<175) { rows[y]++; all.left=Math.min(all.left,x);all.right=Math.max(all.right,x);all.top=Math.min(all.top,y);all.bottom=Math.max(all.bottom,y);all.count++; }
  }
  if (!all.count) return {crop:presetCrop('full'),reason:'No printed area detected. Select the label manually.'};
  const blocks=[];let start=-1,last=-1;
  const gap=Math.max(10,Math.round(height*.025));
  for(let y=0;y<=height+gap;y++) {
    if(y<height && rows[y]>1) {if(start<0)start=y;last=y;}
    if(start>=0 && y-last>=gap){
      let left=width,right=0,count=0;
      for(let yy=start;yy<=last;yy++)for(let x=0;x<width;x++){const i=(yy*width+x)*4;if(data[i+3]>100&&Math.min(data[i],data[i+1],data[i+2])<175){left=Math.min(left,x);right=Math.max(right,x);count++;}}
      blocks.push({left,right,top:start,bottom:last,count});start=-1;
    }
  }
  const candidates=blocks.filter(b=>{const ratio=(b.right-b.left)/(b.bottom-b.top);return b.bottom-b.top>height*.18 && b.right-b.left>width*.25 && ((ratio>.5&&ratio<.86)||(ratio>1.2&&ratio<1.9));});
  const b=candidates.sort((a,b)=>b.count-a.count)[0] || all;
  const pad=Math.max(5,Math.round(Math.min(width,height)*.018));
  const left=Math.max(0,b.left-pad),top=Math.max(0,b.top-pad);
  return {crop:normalizeCrop({x:left/width,y:top/height,w:(Math.min(width,b.right+pad+1)-left)/width,h:(Math.min(height,b.bottom+pad+1)-top)/height}),reason:candidates.length?'Suggested crop from printed label blocks. Verify every barcode and the full address.':'Printed content selected. Use a half-page preset or draw a crop if instructions are included.'};
}
export function cropToPdfBox(viewport,crop) {
  const c=normalizeCrop(crop);
  const points=[[c.x,c.y],[c.x+c.w,c.y],[c.x,c.y+c.h],[c.x+c.w,c.y+c.h]].map(([x,y])=>viewport.convertToPdfPoint(x*viewport.width,y*viewport.height));
  return {left:Math.min(...points.map(p=>p[0])),bottom:Math.min(...points.map(p=>p[1])),right:Math.max(...points.map(p=>p[0])),top:Math.max(...points.map(p=>p[1]))};
}
export function placement(width,height,rotation,targetWidth=288,targetHeight=432) {
  const r=((rotation%360)+360)%360;
  const landscape=r===90||r===270;
  const scale=Math.min(targetWidth/(landscape?height:width),targetHeight/(landscape?width:height));
  const w=width*scale,h=height*scale;
  let x=(targetWidth-(landscape?h:w))/2,y=(targetHeight-(landscape?w:h))/2;
  if(r===90)y+=w;else if(r===180){x+=w;y+=h;}else if(r===270)x+=h;
  return {x,y,width:w,height:h,rotation:-r};
}
export function halfSheetSlot(widthIn,heightIn,position){
  const rotation=heightIn>widthIn?90:0,w=rotation?heightIn:widthIn,h=rotation?widthIn:heightIn;
  if(w>8.5+.001||h>5.5+.001)throw new Error(`${widthIn.toFixed(2)} × ${heightIn.toFixed(2)} in labels do not fit a US Letter half-sheet at actual size. Choose another layout.`);
  return {x:(8.5-w)/2,y:(position===0?5.5:0)+(5.5-h)/2,w,h,rotation};
}
export function quarterSheetSlot(position){
  if(!Number.isInteger(position)||position<0||position>3)throw new Error('Invalid quarter-sheet position.');
  const width=5.5*4/6;
  return {x:(position%2)*4.25+(4.25-width)/2,y:position<2?5.5:0,w:width,h:5.5};
}
export async function exportLabel(PDFLib,sourceBytes,pageIndex,box,rotation) {
  return exportLabels(PDFLib,sourceBytes,[{pageIndex,box,rotation}]);
}
// Compose selected source pages into one 4×6-page document while preserving
// vector text and barcodes. This is also the single-page export implementation.
export async function exportLabels(PDFLib,sourceBytes,selections,targetSize={width:288,height:432}) {
  const source=await PDFLib.PDFDocument.load(sourceBytes);
  const output=await PDFLib.PDFDocument.create();
  for(const {pageIndex,box,rotation=0} of selections){
    const embedded=await output.embedPage(source.getPage(pageIndex),box);
    const target=output.addPage([targetSize.width,targetSize.height]);
    const p=placement(box.right-box.left,box.top-box.bottom,rotation,targetSize.width,targetSize.height);
    target.drawPage(embedded,{x:p.x,y:p.y,width:p.width,height:p.height,rotate:PDFLib.degrees(p.rotation)});
  }
  output.setTitle('4x6 shipping label');output.setCreator('4x6 Label Studio');
  return output.save();
}
