# Label Studio for Chrome

Label Studio turns marketplace and carrier webpage labels, plus ordinary shipping-label PDFs, into print-ready thermal labels. Processing stays in the extension on your computer.

Capture adapters recognize URLs for Amazon, Vinted, eBay, Etsy, Depop, Poshmark, Mercari, Shopify, USPS, UPS, FedEx, and DHL. Their live authenticated workflows have not been verified for this release; download the PDF and import it when capture fails. Each adapter is isolated in `site-adapters.mjs`.

## Install

1. Open Chrome and enter **chrome://extensions**.
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the extracted folder containing `manifest.json`.
4. Pin **Label Studio — 4×6 Labels** from Chrome's puzzle-piece Extensions menu.

The extension remains installed when Chrome restarts. Keep this folder in place. No store publication or signing is needed for Load unpacked. To share it, extract the ZIP into a permanent folder first and load that folder.

## Capture an Amazon return label

1. Open Amazon's **Your Return Instructions** page where the **Return Mailing Label** is displayed.
2. Click the Label Studio toolbar icon while that tab is active.
3. The extension scrolls the mailing label into view, temporarily enlarges it for a higher-resolution capture, and opens it in the editor automatically.
4. Check that the crop includes the complete mailing-label border, address, and every barcode. Adjust the box if needed, then print or save it as a 4×6 PDF.

The adapter attempts to isolate the mailing label rather than a return authorization slip. Amazon can change its page layout, so always verify the preview. If automatic detection cannot isolate the border, select the visible label area manually. Keep the Amazon tab active until the editor opens.

## Capture a Vinted shipping label

Open Vinted's label, download, postage, order, or transaction view and make the label visible. Click the toolbar icon while that tab is active. Label Studio recognizes common label containers and carrier text including Evri, InPost, Royal Mail, Yodel, Hermes, and Mondial Relay. Vinted can serve labels as an inline page, PDF, temporary URL, or download depending on market and carrier; direct page/PDF capture is attempted first, and **Choose PDF** remains the dependable fallback for protected or expired links.

## Batch and crop editing

Multi-page PDFs select every page by default. Deselect, reorder, or remove pages without changing the original PDFs. Copy one crop to selected pages or auto-detect each selected page independently; Undo restores batch crop edits. Drag inside a crop to move it, use the eight handles to resize it, or drag outside to create a new selection. Precise percentage fields and a visual margin guide are available; the guide is not a validated barcode quiet-zone measurement. Save one combined PDF, initiate separate page downloads, or open Chrome print preview for the batch.

The US Letter two-label layout uses portrait 8½ × 11 stock with two 8½ × 5½ half-sheet areas. A 4 × 6 label is rotated sideways at actual size and centered in each half. Print at 100% or actual size with no added margins or headers.

The US Letter four-label layout uses portrait 8½ × 11 stock with four 4¼ × 5½ quarter-sheet areas. Each 4 × 6 label is scaled uniformly to fit and centered in its quarter. Check that the carrier can scan the smaller printed barcode.

## Use the PDF already open in Chrome

1. Select the tab displaying your PDF.
2. Click the Label Studio toolbar icon.
3. In the new editor tab, click **Use current PDF**. For a web PDF, allow access to its site if Chrome asks.
4. Check the crop, then print or save as 4×6.

For PDFs opened from your computer (file URLs), open the extension's **Details** on chrome://extensions and enable **Allow access to file URLs**. The editor's **Local PDF access settings** button opens these settings. Chrome reloads the extension when this setting changes. Return to your original PDF tab and click the Label Studio toolbar icon again, then Use current PDF.

For temporary blob PDFs, click the extension while the label is visible; Label Studio captures the visible page for manual cropping without downloading the protected source. Supported marketplace pages use localized headings plus structural and barcode-like detection, with an on-page area picker when automatic capture cannot isolate the label. Cross-origin viewers and expired links can still require downloading and choosing the PDF.

## Choose a PDF from your files

Click the extension from any tab, then **Choose PDF**. Pick the downloaded PDF, or drag it onto the editor. Choosing a file works without site access or the file-URL setting. It also works offline.

## Printing and exporting

Select the page, check the suggested crop, and keep all barcodes and the full address visible. Profiles include generic 203 and 300 DPI, Zebra 203/300 DPI, Rollo, Munbyn, Brother, DYMO, vector PDF, and custom DPI. Formats include 4×6 portrait, 6×4 landscape, A6, 100×150 mm, and custom dimensions. Optimized output supports automatic thresholding, adjustable darkness, grayscale, and optional sharpening; vector mode preserves original PDF graphics.

Enable **Open print preview automatically after capturing a label** to prepare a toolbar-captured label and open Chrome print preview after checks finish. Warnings pause automatic handoff for review; **Print anyway** is an explicit manual action. Automatic handoff applies only to toolbar sources. Protected web PDFs may still require a click on **Use current PDF** to grant site access, and local PDF tabs require Chrome's **Allow access to file URLs** setting.

Source/output zoom and a one-CSS-pixel-per-printer-dot view help inspect fine text and barcodes. Printer, format, image treatment, rotation behavior, crop preset, and naming preferences are remembered locally. Focus the crop and use arrows to move it, Shift + arrows to resize it, or Alt for larger increments.

Before export, Label Studio checks selected pages for crop-boundary ink, output-edge marks, captured-image resolution, and patterns consistent with merged barcode bars. Output-edge checks do not validate barcode quiet zones. Where Chrome exposes `BarcodeDetector`, it attempts to compare every decoded source barcode with its output. An unavailable or failed decoder is reported. These checks cannot certify a physical scan.

Under **Print preview preferences**, choose whether printing opens from the editor tab or a new tab. The choice is remembered; new tab is the default. Both options prepare the same PDF and open Chrome print preview. Choose the physical printer and settings in Chrome.

In Chrome choose the matching paper size, 100% scale, zero margins, and no headers/footers. Limits: 25 MB per input PDF, 50 MB combined, 100 pages total, 16 million pixels per rendered page, and 64 million pixels for a preview render pass. Password-protected PDFs are unsupported. Automatic crops are suggestions. Physical printer and authenticated live-site checks remain outstanding.

## Privacy and permissions

PDF editing stays in the extension. No analytics, remote code, or advertising are included. File imports work offline. A captured page or source URL is held temporarily in Chrome session storage and removed when consumed. Unconsumed handoffs expire after 30 minutes; physical cleanup occurs on a later toolbar action or when the browser session ends. A requested source PDF is fetched from its original site with browser credentials after the relevant permission is available. **Close label** releases the current document and source reload reference; downloaded PDFs remain where Chrome saved them. Printer setups and preferences are stored locally until reset. Diagnostic summaries are inspected before copying and are never sent automatically.

- activeTab: reads the tab you explicitly click the extension on.
- scripting: finds a visible label region on a supported source tab you explicitly selected.
- storage: holds local preferences and temporary source handoffs across service-worker suspension.
- file URL access: reads a PDF open from disk only after you enable Chrome's file-URL setting and click Use current PDF.
- Optional HTTP/HTTPS site access: requested for the source site when you click Use current PDF. Chrome may retain granted permissions; manage them in extension Details.

No installation or code changes were made to the separate browser-only Label Studio project.

## Developer checks

There is no build step. The folder is directly loadable. Libraries and licenses are in vendor/ and THIRD_PARTY.md. Run `npm test` for unit/regression checks. Run `npm run release` to validate the manifest and JavaScript, run the tests, stage only release files, record dependency versions, and create `release/label-studio-VERSION.zip`. Integration tests use a separate browser test profile and synthetic PDFs, never your personal profile.

Independent tool, not affiliated with Amazon, Vinted, USPS, FedEx, Google, or the original Chrome extension author. See `AI_HANDOFF.md` for architecture and maintenance notes and `CHANGELOG.md` for release details.

## Verification

Verified in Chrome using an isolated test profile: real toolbar action, a synthetic Amazon-style webpage label capture, an open web PDF, an open file-URL PDF, the native file chooser, missing file access, source metadata cleanup, page selection, rotation, PDF download, default 812 × 1218 GK420d print rendering, and invalid/oversized/403 responses. Geometry/export and native printer-dot tests pass. Synthetic fixtures were used; actual Amazon/Vinted authentication and physical printing remain untested.

Chrome installation reference: https://developer.chrome.com/docs/extensions/get-started/tutorial/hello-world#load-unpacked

