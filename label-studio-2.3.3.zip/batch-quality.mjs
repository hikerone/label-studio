export function compareBarcodes(source, output) {
  if (source.status === 'unavailable' || output.status === 'unavailable') return {status:'unavailable', message:'Barcode decoding is unavailable in this Chrome installation. Inspect and scan the printed label.'};
  if (source.status === 'failed' || output.status === 'failed') return {status:'failed', message:'Barcode decoding failed. Inspect and scan the printed label.'};
  if (!source.values.length) return output.values.length
    ? {status:'output-only',message:`${new Set(output.values).size} barcode${new Set(output.values).size===1?'':'s'} decoded in the prepared label; the source could not be compared.`}
    : {status:'none', message:'No barcode was decoded in the source or prepared label. Inspect and scan the printed label.'};
  const missing=[...new Set(source.values)].filter(value=>!output.values.includes(value));
  return missing.length
    ? {status:'missing',message:`${missing.length} of ${new Set(source.values).size} decoded source barcodes did not decode in the output.`}
    : {status:'compared',message:`All ${new Set(source.values).size} decoded source barcode${new Set(source.values).size===1?'':'s'} also decoded in the output.`};
}

export function pageIdentity(origin, index) {
  return {file:origin?.name||'label.pdf',originalPage:origin?.page||index+1,outputPosition:index+1};
}
