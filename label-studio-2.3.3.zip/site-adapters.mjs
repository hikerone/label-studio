export const SITE_ADAPTERS=Object.freeze([
  {id:'amazon',name:'Amazon',hosts:[/(^|\.)amazon\.[a-z.]+$/i],url:/returns|return|label|printerFriendly/i,headings:[/return mailing label/i,/[eé]tiquette de retour/i,/rücksendeetikett/i,/etiqueta de devolución/i,/etichetta di reso/i,/retourlabel/i,/返送用ラベル/i]},
  {id:'vinted',name:'Vinted',hosts:[/(^|\.)vinted\.[a-z.]+$/i],url:/label|shipping|postage|order|transaction|download/i,headings:[/shipping|postage|download|print/i]},
  {id:'ebay',name:'eBay',hosts:[/(^|\.)ebay\.[a-z.]+$/i],headings:[/shipping label|print postage|label/i]},
  {id:'etsy',name:'Etsy',hosts:[/(^|\.)etsy\.com$/i],headings:[/shipping label|postage label/i]},
  {id:'depop',name:'Depop',hosts:[/(^|\.)depop\.com$/i],headings:[/shipping label|label/i]},
  {id:'poshmark',name:'Poshmark',hosts:[/(^|\.)poshmark\.(com|ca)$/i],headings:[/shipping label|label/i]},
  {id:'mercari',name:'Mercari',hosts:[/(^|\.)mercari\.(com|jp)$/i],headings:[/shipping label|label/i]},
  {id:'shopify',name:'Shopify',hosts:[/(^|\.)shopify\.com$/i,/\.myshopify\.com$/i],headings:[/shipping label|buy label|print label/i]},
  {id:'usps',name:'USPS',hosts:[/(^|\.)usps\.com$/i],headings:[/shipping label|click-n-ship|label/i]},
  {id:'ups',name:'UPS',hosts:[/(^|\.)ups\.com$/i],headings:[/shipping label|print label/i]},
  {id:'fedex',name:'FedEx',hosts:[/(^|\.)fedex\.com$/i],headings:[/shipping label|print label|shipment label/i]},
  {id:'dhl',name:'DHL',hosts:[/(^|\.)dhl\.[a-z.]+$/i],headings:[/shipping label|print label|waybill/i]}
]);

export function adapterForUrl(raw,title=''){
  let url;try{url=new URL(raw);}catch{return null;}
  const matched=SITE_ADAPTERS.find(adapter=>adapter.hosts.some(pattern=>pattern.test(url.hostname))&&(!adapter.url||adapter.url.test(url.href+' '+title)));
  if(matched)return matched;
  const semantic=(url.pathname+' '+title).toLowerCase();
  return SITE_ADAPTERS.find(adapter=>new RegExp(`\\b${adapter.id}\\b`,'i').test(semantic))||null;
}

export function headingSource(adapter){return (adapter?.headings||[]).map(pattern=>pattern.source).join('|');}
