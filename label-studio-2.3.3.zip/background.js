const PREFIX='source:';
import {adapterForUrl,headingSource} from './site-adapters.mjs';
function findShippingLabel(site,headingRegex){
  const visible=element=>{const style=getComputedStyle(element),rect=element.getBoundingClientRect();return style.display!=='none'&&style.visibility!=='hidden'&&rect.width>0&&rect.height>0;};
  const headingPattern=new RegExp(headingRegex||'(shipping|postage|return|print).{0,24}label|label.{0,24}(shipping|postage|return|print)','i');
  const headings=[...document.querySelectorAll('h1,h2,h3,h4,h5,h6,div,span')].filter(element=>visible(element)&&headingPattern.test((element.textContent||'').trim()));
  const heading=headings.sort((a,b)=>a.children.length-b.children.length)[0];
  let direct=[...document.querySelectorAll('img,svg,canvas,object,embed,iframe')].filter(element=>{
    if(!visible(element))return false;const rect=element.getBoundingClientRect(),ratio=rect.width/rect.height;
    const hint=((element.getAttribute('aria-label')||'')+' '+(element.getAttribute('alt')||'')+' '+(element.getAttribute('src')||'')).toLowerCase();
    return rect.width>250&&rect.height>300&&ratio>.5&&ratio<1.05&&/(label|shipping|postage|pdf)/.test(hint);
  }).sort((a,b)=>b.getBoundingClientRect().width*b.getBoundingClientRect().height-a.getBoundingClientRect().width*a.getBoundingClientRect().height)[0];
  if(!heading&&!direct){
    const structural=[...document.querySelectorAll('svg,canvas,img,section,article,div')].filter(element=>{if(!visible(element))return false;const rect=element.getBoundingClientRect(),text=(element.innerText||element.getAttribute?.('aria-label')||'').toUpperCase(),bars=element.querySelectorAll?.('svg line,svg rect,canvas').length||0;return rect.width>280&&rect.height>180&&rect.width/rect.height>.5&&rect.width/rect.height<2.2&&(bars>18||/TRACKING|SHIP\s*TO|WAYBILL|USPS|UPS|FEDEX|DHL/.test(text));}).sort((a,b)=>b.getBoundingClientRect().width*b.getBoundingClientRect().height-a.getBoundingClientRect().width*a.getBoundingClientRect().height);
    if(structural[0])direct=structural[0];else return null;
  }
  const headingRect=(heading||direct).getBoundingClientRect();
  const candidates=[];
  for(const element of document.querySelectorAll('div,section,article,table,img,svg,canvas')){
    if(!visible(element)||(heading&&element.contains(heading)))continue;
    const rect=element.getBoundingClientRect(),ratio=rect.width/rect.height;
    if(rect.width<280||rect.height<180||rect.width>1100||rect.height>800||ratio<1.15||ratio>2.15)continue;
    const absoluteTop=rect.top+scrollY,headingBottom=headingRect.bottom+scrollY;
    if(absoluteTop<headingBottom-20||absoluteTop>headingBottom+1400)continue;
    const style=getComputedStyle(element),labelText=(element.innerText||'').toUpperCase();
    let score=0;
    if(/dashed|dotted/.test(style.borderTopStyle+style.borderRightStyle+style.borderBottomStyle+style.borderLeftStyle))score+=1000;
    if(/^(IMG|SVG|CANVAS)$/.test(element.tagName))score+=180;
    if(/SHIP\s*TO|TRACKING|UPS\s+GROUND|USPS|FEDEX|EVRI|INPOST|ROYAL\s*MAIL|YODEL|HERMES|MONDIAL\s*RELAY/.test(labelText))score+=240;
    if(/1\s+OF\s+1/.test(labelText))score+=80;
    score+=Math.min(100,element.querySelectorAll('img,svg,canvas').length*20);
    score-=Math.abs(1.5-ratio)*80;
    score-=Math.max(0,absoluteTop-headingBottom)*.03;
    candidates.push({element,score});
  }
  const best=candidates.sort((a,b)=>b.score-a.score)[0];
  const target=direct||(best&&best.score>100?best.element:heading);
  target.scrollIntoView({block:'center',inline:'center'});
  return new Promise(resolve=>setTimeout(()=>{
    if(target===heading){resolve({found:true,crop:null,site});return;}
    const rect=target.getBoundingClientRect(),availableWidth=innerWidth-32,availableHeight=innerHeight-32;
    const scale=Math.max(1,Math.min(3,availableWidth/rect.width,availableHeight/rect.height));
    const overlay=document.createElement('div');overlay.id='label-studio-capture-overlay';
    Object.assign(overlay.style,{position:'fixed',inset:'0',zIndex:'2147483647',background:'#fff',display:'flex',alignItems:'center',justifyContent:'center',overflow:'hidden'});
    const clone=target.cloneNode(true);
    Object.assign(clone.style,{position:'static',inset:'auto',margin:'0',width:rect.width+'px',height:rect.height+'px',maxWidth:'none',maxHeight:'none',transform:`scale(${scale})`,transformOrigin:'center',boxSizing:'border-box'});
    overlay.append(clone);document.documentElement.append(overlay);
    if(target instanceof HTMLCanvasElement&&clone instanceof HTMLCanvasElement){clone.width=target.width;clone.height=target.height;clone.getContext('2d').drawImage(target,0,0);}
    setTimeout(()=>{
      const enlarged=clone.getBoundingClientRect(),pad=3,left=Math.max(0,enlarged.left-pad),top=Math.max(0,enlarged.top-pad);
      resolve({found:true,overlay:true,site,crop:{x:left/innerWidth,y:top/innerHeight,w:(Math.min(innerWidth,enlarged.right+pad)-left)/innerWidth,h:(Math.min(innerHeight,enlarged.bottom+pad)-top)/innerHeight}});
    },300);
  },250));
}
function removeLabelCaptureOverlay(){document.getElementById('label-studio-capture-overlay')?.remove();}
function selectVisibleLabelArea(provider){return new Promise(resolve=>{
  document.getElementById('label-studio-area-picker')?.remove();const root=document.createElement('div');root.id='label-studio-area-picker';root.tabIndex=0;root.setAttribute('role','dialog');root.setAttribute('aria-label','Select the visible label area');Object.assign(root.style,{position:'fixed',inset:'0',zIndex:'2147483647',cursor:'crosshair',background:'#002c2c33'});
  const tip=document.createElement('div');tip.textContent=`Drag around the visible ${provider} label, or use the whole visible area and adjust the crop in Label Studio. Esc cancels.`;Object.assign(tip.style,{position:'fixed',top:'16px',left:'50%',transform:'translateX(-50%)',maxWidth:'min(560px,90vw)',background:'#153f3f',color:'white',padding:'10px 14px',borderRadius:'8px',font:'600 13px system-ui',pointerEvents:'none'});const whole=document.createElement('button');whole.type='button';whole.textContent='Use whole visible area';Object.assign(whole.style,{position:'fixed',top:'76px',left:'50%',transform:'translateX(-50%)',padding:'10px 14px',background:'#087f80',color:'white',border:'2px solid white',borderRadius:'8px',font:'700 13px system-ui',cursor:'pointer'});const box=document.createElement('div');Object.assign(box.style,{position:'fixed',border:'3px solid #00a6a6',background:'#00a6a611',display:'none',pointerEvents:'none'});root.append(tip,whole,box);const previous=document.activeElement;document.documentElement.append(root);whole.focus();let start=null;
  const done=value=>{root.remove();if(!value&&previous?.isConnected)previous.focus();resolve(value);};whole.addEventListener('pointerdown',e=>e.stopPropagation());whole.addEventListener('pointerup',e=>e.stopPropagation());whole.addEventListener('click',()=>done({x:0,y:0,w:1,h:1}));root.addEventListener('keydown',e=>{if(e.key==='Escape')done(null);});root.addEventListener('pointerdown',e=>{start={x:e.clientX,y:e.clientY};box.style.display='block';});root.addEventListener('pointermove',e=>{if(!start)return;Object.assign(box.style,{left:Math.min(start.x,e.clientX)+'px',top:Math.min(start.y,e.clientY)+'px',width:Math.abs(e.clientX-start.x)+'px',height:Math.abs(e.clientY-start.y)+'px'});});root.addEventListener('pointerup',e=>{if(!start)return;const left=Math.min(start.x,e.clientX),top=Math.min(start.y,e.clientY),w=Math.abs(e.clientX-start.x),h=Math.abs(e.clientY-start.y);done(w>30&&h>30?{x:left/innerWidth,y:top/innerHeight,w:w/innerWidth,h:h/innerHeight}:null);});
});}
async function cropVisibleCapture(dataUrl,crop){if(!crop||crop.x===0&&crop.y===0&&crop.w===1&&crop.h===1)return {dataUrl,crop};const bitmap=await createImageBitmap(new Blob([Uint8Array.from(atob(dataUrl.slice(dataUrl.indexOf(',')+1)),char=>char.charCodeAt(0))],{type:'image/png'}));try{const x=Math.max(0,Math.floor(crop.x*bitmap.width)),y=Math.max(0,Math.floor(crop.y*bitmap.height)),width=Math.max(1,Math.min(bitmap.width-x,Math.ceil(crop.w*bitmap.width))),height=Math.max(1,Math.min(bitmap.height-y,Math.ceil(crop.h*bitmap.height))),canvas=new OffscreenCanvas(width,height),context=canvas.getContext('2d');context.drawImage(bitmap,x,y,width,height,0,0,width,height);const bytes=new Uint8Array(await (await canvas.convertToBlob({type:'image/png'})).arrayBuffer());let binary='';for(let offset=0;offset<bytes.length;offset+=8192)binary+=String.fromCharCode(...bytes.subarray(offset,offset+8192));return {dataUrl:'data:image/png;base64,'+btoa(binary),crop:{x:0,y:0,w:1,h:1}};}finally{bitmap.close();}}
async function captureWebLabel(tab){
  if(!tab.id)return null;
  if(/^blob:/i.test(tab.url||'')){const dataUrl=await chrome.tabs.captureVisibleTab(tab.windowId,{format:'png'});return {kind:'image',dataUrl,crop:null,site:'embedded',name:'temporary-pdf-label.png',title:'Visible temporary PDF',expires:Date.now()+30*60*1000};}
  if(!/^https?:/i.test(tab.url||''))return null;
  const adapter=adapterForUrl(tab.url,tab.title||'');if(!adapter)return null;const site=adapter.id;
  let overlay=false;
  try{
    let [result]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:findShippingLabel,args:[site,headingSource(adapter)]});
    if(!result?.result?.found){const [manual]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:selectVisibleLabelArea,args:[adapter.name]});if(!manual?.result)return null;result={result:{found:true,crop:manual.result,site}};}
    overlay=!!result.result.overlay;
    const active=await chrome.tabs.query({active:true,windowId:tab.windowId});
    if(active[0]?.id!==tab.id)throw new Error(`Keep the ${site==='vinted'?'Vinted':'Amazon'} label tab active until Label Studio opens.`);
    const capture=await cropVisibleCapture(await chrome.tabs.captureVisibleTab(tab.windowId,{format:'png'}),result.result.crop);
    return {kind:'image',...capture,site,name:`${site}-shipping-label.png`,title:`${adapter.name} label`,expires:Date.now()+30*60*1000};
  }catch(error){
    return {kind:'capture-error',site,provider:adapter.name,message:`The ${adapter.name} label could not be captured. Keep the source tab active and try again.`,expires:Date.now()+30*60*1000};
  }finally{
    if(overlay)try{await chrome.scripting.executeScript({target:{tabId:tab.id},func:removeLabelCaptureOverlay});}catch{}
  }
}
export async function openEditorForTab(tab) {
  const stored=await chrome.storage.session.get(null);
  const expired=Object.entries(stored).filter(([key,value])=>key.startsWith(PREFIX)&&(!value.expires||value.expires<Date.now())).map(([key])=>key);
  if(expired.length)await chrome.storage.session.remove(expired);
  const token=crypto.randomUUID();
  const captured=await captureWebLabel(tab);
  await chrome.storage.session.set({[PREFIX+token]:captured||{kind:'pdf',url:tab.url||'',title:tab.title||'',expires:Date.now()+30*60*1000}});
  try { return await chrome.tabs.create({url:chrome.runtime.getURL('editor.html#'+token)}); }
  catch(error){await chrome.storage.session.remove(PREFIX+token);throw error;}
}
chrome.action.onClicked.addListener(tab=>{
  openEditorForTab(tab).catch(async()=>{const token=crypto.randomUUID();await chrome.storage.session.set({[PREFIX+token]:{kind:'capture-error',provider:'Source',message:'Capture processing failed. Return to the source tab or choose a downloaded PDF.',expires:Date.now()+60_000}});await chrome.tabs.create({url:chrome.runtime.getURL('editor.html#'+token)});});
});
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(sender.id!==chrome.runtime.id || message?.type!=='take-source' || typeof message.token!=='string' || !/^[a-f0-9-]{36}$/.test(message.token))return false;
  if(!sender.url?.startsWith(chrome.runtime.getURL('editor.html')))return false;
  const key=PREFIX+message.token;
  (async()=>{const saved=(await chrome.storage.session.get(key))[key];await chrome.storage.session.remove(key);reply(saved?.expires>Date.now()?saved:null);})().catch(()=>reply(null));
  return true;
});
