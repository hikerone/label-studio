import * as pdfjs from './vendor/pdf.mjs';
pdfjs.GlobalWorkerOptions.workerSrc=new URL('./vendor/pdf.worker.mjs',import.meta.url).href;
const params=new URLSearchParams(location.search),width=Number(params.get('width')),height=Number(params.get('height')),dpi=Number(params.get('dpi')),source=params.get('pdf'),message=document.getElementById('message'),pages=document.getElementById('pages');
async function prepare(){
  if(!source?.startsWith(`blob:${location.origin}/`)||!Number.isFinite(width)||!Number.isFinite(height)||width<1||height<1||width>20||height>20||!Number.isFinite(dpi)||dpi<100||dpi>1200)throw new Error('Invalid print document. Return to Label Studio and try again.');
  const style=document.createElement('style');style.textContent=`@page{size:${width}in ${height}in;margin:0}.sheet{width:${width}in;height:${height}in}`;document.head.append(style);
  const response=await fetch(source);if(!response.ok)throw new Error('The print document expired. Return to Label Studio and try again.');
  const bytes=new Uint8Array(await response.arrayBuffer()),task=pdfjs.getDocument({data:bytes,isEvalSupported:false,useWasm:false,useWorkerFetch:false,standardFontDataUrl:new URL('./vendor/standard_fonts/',import.meta.url).href,cMapUrl:new URL('./vendor/cmaps/',import.meta.url).href,cMapPacked:true}),doc=await task.promise;
  try{if(doc.numPages>100)throw new Error('Too many print pages.');for(let index=1;index<=doc.numPages;index++){message.textContent=`Preparing page ${index} of ${doc.numPages}…`;const page=await doc.getPage(index),unit=page.getViewport({scale:1}),scale=Math.min(dpi/72,Math.sqrt(16_000_000/(unit.width*unit.height))),viewport=page.getViewport({scale}),canvas=document.createElement('canvas');canvas.className='sheet';canvas.width=Math.round(viewport.width);canvas.height=Math.round(viewport.height);await page.render({canvasContext:canvas.getContext('2d'),viewport,background:'white'}).promise;pages.append(canvas);}message.textContent='Print preview is opening. Check paper size and actual scale.';requestAnimationFrame(()=>setTimeout(()=>window.print(),300));}finally{await doc.destroy();}
}
prepare().catch(error=>{message.textContent=error.message;});
