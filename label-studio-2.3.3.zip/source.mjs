const MAX_BYTES=25*1024*1024;
export function resolvePdfUrl(raw) {
  let url;try{url=new URL(raw);}catch{return null;}
  // Chrome normally exposes the original PDF URL in tabs.Tab.url.
  // Also handle URLs copied directly from its built-in PDF viewer.
  if(url.protocol==='chrome-extension:'&&url.hostname==='mhjfbmdgcfjbbpaeojofohoefgiehjai'){
    const original=url.searchParams.get('file')||url.searchParams.get('src');
    if(original){try{url=new URL(original);}catch{return null;}}
  }
  if(!['https:','http:','file:'].includes(url.protocol))return null;
  if(url.username||url.password)return null;
  url.hash='';return url;
}
export async function readPdfUrl(url) {
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),30000);
  try{
    const response=await fetch(url.href,{credentials:'include',redirect:'manual',signal:controller.signal});
    if(response.type==='opaqueredirect'||(response.status>=300&&response.status<400))throw new Error('The source redirected to another URL. Download the PDF and use Choose PDFs.');
    if(!response.ok)throw new Error('The PDF could not be downloaded ('+response.status+').');
    if(Number(response.headers.get('content-length'))>MAX_BYTES){await response.body?.cancel();throw new Error('The PDF exceeds the 25 MB limit.');}
    if(!response.body)throw new Error('The tab returned an empty response.');
    const reader=response.body.getReader();const chunks=[];let size=0;
    while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>MAX_BYTES){await reader.cancel();throw new Error('The PDF exceeds the 25 MB limit.');}chunks.push(value);}
    const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
    if(!new TextDecoder().decode(bytes.slice(0,1024)).includes('%PDF-'))throw new Error('This tab did not return a PDF. Open the PDF itself, or choose its downloaded file.');
    let name='shipping-label.pdf';try{const part=decodeURIComponent(url.pathname.split('/').pop());if(/\.pdf$/i.test(part))name=part;}catch{}
    return {bytes,name};
  }finally{clearTimeout(timer);}
}
export async function initCurrentSource({openPdf,openImage,busy,isBusy,hasSource,status,autoPrint=false,requestAutoPrint=()=>{}}) {
  const button=document.getElementById('source'),hint=document.getElementById('sourcehint'),settings=document.getElementById('file-access');
  settings.addEventListener('click',()=>chrome.tabs.create({url:'chrome://extensions/?id='+chrome.runtime.id}));
  const token=location.hash.slice(1);history.replaceState(null,'',location.pathname);
  let saved=token?await chrome.runtime.sendMessage({type:'take-source',token}):null;
  if(saved?.kind==='image'&&saved.dataUrl){
    button.dataset.available='true';button.textContent='Reload captured label';
    const provider=saved.title||`${saved.site||'web'} label`;hint.textContent=`Captured from the ${provider} page.`;
    const load=async automatic=>{if(isBusy())return;try{if(automatic)requestAutoPrint();await openImage(saved.dataUrl,saved.name,saved.crop,saved.site);}catch(error){status('Could not open the captured label: '+error.message,true);}};
    button.addEventListener('click',()=>load(false));await load(autoPrint);return ()=>{saved=null;button.dataset.available='false';button.disabled=true;button.textContent='Use current PDF';hint.textContent='Return to the source tab and click the extension again to recapture.';};
  }
  if(saved?.kind==='capture-error'){
    const provider=saved.provider||(saved.site==='vinted'?'Vinted':'Amazon');button.disabled=true;hint.textContent=provider+' label capture was not available.';
    status(saved.message+` Make sure the label is visible, then return to ${provider} and click the extension again. You can always download and choose the PDF.`,true);return;
  }
  const sourceTitle=saved?.title,sourceWasBlob=saved?.url?.startsWith('blob:');let url=resolvePdfUrl(saved?.url);saved=null;
  if(!url){
    button.disabled=true;
    hint.textContent=sourceWasBlob?'Chrome protects this temporary PDF link. Reopen it and click the extension to capture the visible page, or choose a downloaded copy.':'To use an open PDF, switch to its tab and click the Label Studio extension. You can choose a file here anytime.';
    settings.hidden=false;
    if(!hasSource()&&!isBusy())status('Choose a PDF file to start.');return;
  }
  button.dataset.available='true';button.disabled=isBusy();
  hint.textContent='Current tab: '+(sourceTitle||url.pathname.split('/').pop()||url.hostname);
  if(url.protocol==='file:'){
    settings.hidden=false;
    if(!await chrome.extension.isAllowedFileSchemeAccess())hint.textContent='For the PDF open from your computer, enable “Allow access to file URLs” in Local PDF access settings. Or choose the file below.';
  }
  const loadPdf=async({requestPermission=false,automatic=false}={})=>{
    if(isBusy())return;
    let permission;
    // Begin optional host permission requests directly in the user click.
    if(requestPermission&&url.protocol!=='file:')permission=chrome.permissions.request({origins:[url.protocol+'//'+url.hostname+'/*']});
    busy(true);
    try{
      if(url.protocol==='file:'){
        if(!await chrome.extension.isAllowedFileSchemeAccess())throw new Error('Enable “Allow access to file URLs” in Local PDF access settings, then reopen Label Studio from the original PDF tab. You can also use Choose PDF.');
      }else if(requestPermission&&!await permission)throw new Error('Site access was not granted. Use Choose PDF for a downloaded copy.');
      status('Reading the PDF from your original tab…');
      const {bytes,name}=await readPdfUrl(url);
      if(automatic)requestAutoPrint();busy(false);await openPdf(bytes,name);
    }catch(error){status(error.name==='AbortError'?'The source did not respond within 30 seconds. Download the PDF and use Choose PDF.':(automatic?'Automatic loading was not available. Click Use current PDF to grant access, or choose a downloaded copy.':error.message+' If needed, download the PDF and use Choose PDF.'),true);}
    finally{busy(false);}
  };
  button.addEventListener('click',()=>loadPdf({requestPermission:true}));
  if(autoPrint)await loadPdf({automatic:true});
  if(!hasSource()&&!isBusy())status('Use the PDF from your original tab, or choose a PDF from your files.');
  return ()=>{url=null;button.dataset.available='false';button.disabled=true;button.textContent='Use current PDF';hint.textContent='Return to the source tab and click the extension again to reload.';};
}
