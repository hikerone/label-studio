export const GK420D_WIDTH=812;
export const GK420D_HEIGHT=1218;
export const GK420D_THRESHOLD=165;

export const PAPER_PRESETS=Object.freeze({
  '4x6':{name:'4 × 6 in · portrait',widthIn:4,heightIn:6},
  '6x4':{name:'6 × 4 in · landscape',widthIn:6,heightIn:4},
  a6:{name:'A6 · 105 × 148 mm',widthIn:105/25.4,heightIn:148/25.4},
  '100x150':{name:'100 × 150 mm',widthIn:100/25.4,heightIn:150/25.4}
});

// Models sharing a resolution retain explicit entries so the saved choice
// matches the name printed on the user's hardware.
export const PRINTER_PROFILES=Object.freeze({
  generic203:{name:'Generic 203 DPI',dpi:203,width:812,height:1218,optimized:true},
  generic300:{name:'Generic 300 DPI',dpi:300,width:1200,height:1800,optimized:true},
  gk420d:{name:'Zebra GK420d · 203 DPI',dpi:203,width:812,height:1218,optimized:true},
  zebra300:{name:'Zebra ZD421 / ZD621 · 300 DPI',dpi:300,width:1200,height:1800,optimized:true},
  rollo:{name:'Rollo · 203 DPI',dpi:203,width:812,height:1218,optimized:true},
  munbyn:{name:'Munbyn · 203 DPI',dpi:203,width:812,height:1218,optimized:true},
  brother:{name:'Brother QL 4-inch · 300 DPI',dpi:300,width:1200,height:1800,optimized:true},
  dymo:{name:'DYMO 4XL / 5XL · 300 DPI',dpi:300,width:1200,height:1800,optimized:true},
  standard:{name:'Standard printer · vector PDF',dpi:300,width:1200,height:1800,optimized:false},
  custom:{name:'Custom paper and DPI',dpi:203,width:812,height:1218,optimized:true}
});

export function customProfile(widthIn,heightIn,dpi){
  const safeWidth=Math.min(12,Math.max(1,Number(widthIn)||4));
  const safeHeight=Math.min(24,Math.max(1,Number(heightIn)||6));
  const safeDpi=Math.min(1200,Math.max(100,Math.round(Number(dpi)||203)));
  const width=Math.round(safeWidth*safeDpi),height=Math.round(safeHeight*safeDpi);
  if(width*height>16_000_000)throw new RangeError('Custom size and DPI exceed the 16 million pixel limit. Reduce either value.');
  return {name:`Custom ${safeWidth}×${safeHeight} in · ${safeDpi} DPI`,dpi:safeDpi,width,height,widthIn:safeWidth,heightIn:safeHeight,optimized:true};
}

// Convert antialiased browser pixels to the printer's two physical dot states.
// There is deliberately no dithering: a barcode module stays solid instead of
// becoming a checkerboard that a 203-DPI thermal printer can reproduce poorly.
export function binarizeImageData(imageData,threshold=GK420D_THRESHOLD){
  const data=imageData?.data;
  if(!data||data.length%4)throw new TypeError('Expected RGBA image data.');
  for(let i=0;i<data.length;i+=4){
    const alpha=data[i+3];
    const luma=(54*data[i]+183*data[i+1]+19*data[i+2])>>8;
    const onWhite=Math.round((luma*alpha+255*(255-alpha))/255);
    const dot=onWhite<threshold?0:255;
    data[i]=data[i+1]=data[i+2]=dot;data[i+3]=255;
  }
  return imageData;
}

export function automaticThreshold(imageData){
  const data=imageData?.data;if(!data?.length)return GK420D_THRESHOLD;
  const histogram=new Uint32Array(256);let count=0;
  for(let i=0;i<data.length;i+=4){const a=data[i+3];if(a<16)continue;histogram[(54*data[i]+183*data[i+1]+19*data[i+2])>>8]++;count++;}
  if(!count)return GK420D_THRESHOLD;
  let total=0;for(let i=0;i<256;i++)total+=i*histogram[i];
  let background=0,foreground=0,best=-1,threshold=GK420D_THRESHOLD;
  for(let i=0;i<256;i++){background+=histogram[i];if(!background)continue;foreground=count-background;if(!foreground)break;let sum=0;for(let j=0;j<=i;j++)sum+=j*histogram[j];const meanBack=sum/background,meanFore=(total-sum)/foreground,variance=background*foreground*(meanBack-meanFore)**2;if(variance>best){best=variance;threshold=i;}}
  return Math.min(220,Math.max(90,threshold));
}

export function processImageData(imageData,{mode='auto',darkness=0,sharpen=false}={}){
  const {data,width,height}=imageData;if(!data||!width||!height)throw new TypeError('Expected RGBA image data with dimensions.');
  const source=sharpen?new Uint8ClampedArray(data):null;
  if(sharpen&&width>2&&height>2)for(let y=1;y<height-1;y++)for(let x=1;x<width-1;x++)for(let c=0;c<3;c++){const i=(y*width+x)*4+c;data[i]=Math.max(0,Math.min(255,source[i]*5-source[i-4]-source[i+4]-source[i-width*4]-source[i+width*4]));}
  const offset=Math.round(Number(darkness)||0);
  for(let i=0;i<data.length;i+=4){const alpha=data[i+3],luma=(54*data[i]+183*data[i+1]+19*data[i+2])>>8,value=Math.max(0,Math.min(255,Math.round((luma*alpha+255*(255-alpha))/255)+offset));data[i]=data[i+1]=data[i+2]=value;data[i+3]=255;}
  if(mode==='grayscale')return imageData;
  return binarizeImageData(imageData,mode==='auto'?automaticThreshold(imageData):GK420D_THRESHOLD);
}

export function paperProfile(base,preset='4x6',customPaper){
  const paper=preset==='custom'?customPaper:PAPER_PRESETS[preset]||PAPER_PRESETS['4x6'];
  const widthIn=Math.min(12,Math.max(1,Number(paper?.widthIn)||4)),heightIn=Math.min(24,Math.max(1,Number(paper?.heightIn)||6));
  const width=Math.round(widthIn*base.dpi),height=Math.round(heightIn*base.dpi);
  if(width*height>16_000_000)throw new RangeError('Paper size and DPI exceed the 16 million pixel limit. Reduce either value.');
  return {...base,widthIn,heightIn,width,height};
}

// A crop reaching the page edge is harmless when that part of the page is
// blank. Only report a cut-off risk when ink actually enters a thin strip on
// the inside of the crop. This also works for manually drawn interior crops.
export function cropTouchesInk(imageData,crop,{threshold=190}={}){
  const {data,width,height}=imageData||{};
  if(!data||!width||!height)return false;
  const left=Math.max(0,Math.min(width-1,Math.round(crop.x*width)));
  const top=Math.max(0,Math.min(height-1,Math.round(crop.y*height)));
  const right=Math.max(left,Math.min(width-1,Math.round((crop.x+crop.w)*width)-1));
  const bottom=Math.max(top,Math.min(height-1,Math.round((crop.y+crop.h)*height)-1));
  const strip=Math.max(1,Math.round(Math.min(right-left+1,bottom-top+1)*.004));
  const dark=(x,y)=>{const i=(y*width+x)*4,a=data[i+3];if(a<32)return false;return ((54*data[i]+183*data[i+1]+19*data[i+2])>>8)<threshold;};
  const sideHasInk=(horizontal,start,end,fixed)=>{
    let ink=0,total=0;
    for(let along=start;along<=end;along++)for(let offset=0;offset<strip;offset++){
      const x=horizontal?along:fixed+offset,y=horizontal?fixed+offset:along;
      total++;if(dark(x,y))ink++;
    }
    return ink>=Math.max(3,Math.ceil(total*.003));
  };
  return sideHasInk(true,left,right,top)||sideHasInk(true,left,right,bottom-strip+1)||sideHasInk(false,top,bottom,left)||sideHasInk(false,top,bottom,right-strip+1);
}

export function effectiveSourceDpi(pixelWidth,pixelHeight,rotation,outputWidthIn,outputHeightIn){
  const quarterTurns=Math.abs(Math.round((Number(rotation)||0)/90))%2;
  const width=quarterTurns?pixelHeight:pixelWidth,height=quarterTurns?pixelWidth:pixelHeight;
  // The image is fitted without distortion. The limiting output dimension
  // determines the actual source pixels per printed inch.
  return Math.max(width/outputWidthIn,height/outputHeightIn);
}

// Conservative carrier-agnostic checks: warn rather than block because label
// artwork varies and a false positive must not prevent an urgent shipment.
export function analyzePrintQuality(sourceImage,convertedImage,{cropTouchesBoundary=false,minSourceDpi=150}={}){
  const warnings=[];
  if(cropTouchesBoundary)warnings.push({code:'boundary',message:'The crop touches printed content. Add space around the label so a barcode is not cut off.'});
  if(Number.isFinite(sourceImage?.estimatedDpi)&&sourceImage.estimatedDpi<minSourceDpi)warnings.push({code:'resolution',message:`Source resolution is about ${Math.round(sourceImage.estimatedDpi)} DPI; 150 DPI or more is recommended.`});
  if(!convertedImage?.data||!convertedImage.width||!convertedImage.height)return warnings;
  const {data,width,height}=convertedImage,dark=(x,y)=>data[(y*width+x)*4]<80;
  const margin=Math.max(2,Math.round(Math.min(width,height)*.012));
  let edge=0,totalEdge=0;
  for(let y=0;y<height;y+=Math.max(1,Math.floor(height/300)))for(let x=0;x<width;x+=Math.max(1,Math.floor(width/300))){
    if(x<margin||x>=width-margin||y<margin||y>=height-margin){totalEdge++;if(dark(x,y))edge++;}
  }
  if(totalEdge&&edge/totalEdge>.015)warnings.push({code:'edge-ink',message:'Dark marks are very close to the output edge. Inspect margins and barcode spacing; this is not a validated quiet-zone measurement.'});
  let suspiciousRows=0,samples=0;
  for(let y=Math.floor(height*.15);y<Math.floor(height*.9);y+=Math.max(1,Math.floor(height/80))){
    let last=dark(0,y),run=1,rowTransitions=0,rowLongDarkRuns=0;
    for(let x=1;x<width;x++){const value=dark(x,y);if(value!==last){rowTransitions++;if(last&&run>width*.08)rowLongDarkRuns++;run=1;last=value;}else run++;}
    if(last&&run>width*.08)rowLongDarkRuns++;
    // Keep the two signals on the same scan line. Aggregating them across
    // unrelated rows made ordinary text plus a page border look like damage.
    if(rowLongDarkRuns&&rowTransitions>25)suspiciousRows++;
    samples++;
  }
  if(samples&&suspiciousRows>Math.max(2,samples*.08))warnings.push({code:'merged-bars',message:'Some barcode bars may have merged. Try vector output or a higher-DPI profile.'});
  return warnings;
}
