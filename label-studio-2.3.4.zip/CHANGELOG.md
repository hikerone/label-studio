# Changelog

## 2.3.4 — 2026-09-23

- Remove the duplicate A4 choice from **Print on**. Existing setups using it fall back to one label per page.
- Automatically detect a separate crop for every new page when importing multiple PDFs, before preparing batch output. Previously, only pages opened through their thumbnails received automatic detection.
- Preserve crops already edited in the current batch when adding more PDFs.

## 2.3.3 — 2026-09-23

- Let users choose whether Chrome print preview opens from the editor tab or a new tab; show the choice as two radio buttons.

- Bundle an offline ZXing barcode decoder for Chrome installations without the optional BarcodeDetector API.
- Retry source PDF barcode checks at higher resolution when the first render finds no code, and accept a decoded prepared label when the source still cannot be compared.
- Check vector output barcodes at full printer resolution when the smaller preview cannot decode them, and show a missing-barcode warning only once.
- Place US Letter two-up labels on a portrait sheet, centered at actual size in the top and bottom 8½ × 5½ half-sheet areas.
- Place US Letter four-up labels in the four 4¼ × 5½ quarters of a portrait sheet, centered with uniform scaling.

## 2.3.2 — 2026-09-23

- Print the prepared output using the selected printer profile and native thermal dot resolution; avoid a second 300 DPI conversion.

## 2.3.1 — 2026-09-23

- Open Chrome print preview automatically for prepared labels instead of stopping at a PDF tab.
- Treat unavailable browser barcode decoding as a capability notice while retaining crop and image warnings.

## 2.3.0 — 2026-09-23

- Added page-specific batch preflight, reversible batch crop edits, Add PDFs, page reorder/removal, cancellation, and bounded preview rendering.
- Open the source PDF artwork in Chrome for printing; saved PDFs still use the selected rendering profile. Added exact-size sheet placement checks and explicit reduced four-up warnings.
- Added named local printer setups, preference reset, inspectable diagnostics, and a synthetic calibration label with barcode and ruler.
- Strengthened staged-package checks and prepared publication drafts. Physical printer, live-site, public-policy URL, and support checks remain open.

## 2.2.0 — 2026-09-23

- Added a remembered option to open Chrome print preview automatically after a label is captured from the toolbar.
- Open web and local PDFs now attempt to load immediately when auto-print is enabled, with the existing permission and file-picker controls retained as fallbacks.
- Added multi-PDF import, page thumbnails, dynamic filenames and action counts, improved zoom controls, mobile crop/preview tabs, and a sticky export area.
- Added landscape US Letter one-up, two-up, and reduced four-up sheet layouts plus landscape A4 two-up output for laser and inkjet printers.

## 2.1.0 — 2026-09-22

- Added isolated marketplace and carrier adapters, localized Amazon headings, structural detection, manual area selection, and visible blob-PDF capture.
- Added automatic threshold, darkness adjustment, grayscale, sharpening, preview zoom, and printer-dot inspection.
- Added portrait, landscape, A6, 100×150 mm, and custom formats.
- Added keyboard crop editing, larger targets, focus treatment, and screen-reader instructions.
- Persisted printer, format, image, rotation, crop preset, and naming preferences.
- Added first-run guidance, regression tests, and a validated ZIP release command.

## 2.0.0 — 2026-09-22

- Added Vinted label/download-page recognition and common European carrier hints, with manual PDF import retained as fallback.
- Added generic 203/300 DPI, Zebra 203/300 DPI, Rollo, Munbyn, Brother, DYMO, vector, and custom paper/DPI profiles.
- Saved the preferred printer and custom dimensions in local extension storage.
- Added crop-boundary, quiet-zone, source-resolution, and merged-bar warnings plus optional browser-native barcode decode comparison.
- Added multi-page selection, shared crop, per-page auto-detection, combined/separate PDF export, and batch printing.
- Added crop undo/reset, move/resize handles, fit-to-content, and a visible safe-zone overlay.
- Added batch/profile/quality unit coverage and Vinted capture coverage in the isolated Chrome suite.
- Preserved local-only processing, bounded PDF size/page limits, short-lived source handoff, and user-initiated host permissions.
